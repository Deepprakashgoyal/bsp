export * from './config-navigation';

export { default as NavMobile } from './mobile/NavMobile';
export { default as NavDesktop } from './desktop/NavDesktop';
