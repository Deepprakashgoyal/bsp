export { default as CareerHeroIllustration } from './CareerHeroIllustration';
export { default as ElearningHeroIllustration } from './ElearningHeroIllustration';
