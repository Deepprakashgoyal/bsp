import '../../../App.css';

import {
  Succeess
} from '../components';

// ----------------------------------------------------------------------

export default function SuccessView() {

  return (
    <Succeess/>
  );
}
