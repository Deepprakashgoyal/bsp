import '../../../App.css';

import {
  Lock
} from '../components';

// ----------------------------------------------------------------------

export default function LockView() {

  return (
    <Lock/>
  );
}
