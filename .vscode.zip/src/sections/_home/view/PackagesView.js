import '../../../App.css';

import {
  Packages
} from '../components';

// ----------------------------------------------------------------------

export default function PackagesView() {

  return (
    <Packages/>
  );
}
