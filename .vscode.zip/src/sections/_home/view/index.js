export { default as LandingView } from './LandingView';
export { default as HomeView } from './HomeView';
export { default as PackagesView} from './PackagesView';
export { default as LockView } from './LockView';
export { default as SuccessView } from './SuccessView';