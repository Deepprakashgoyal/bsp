// @mui
import RemoveModeratorIcon from '@mui/icons-material/RemoveModerator';
import { Box, Button, Container, Paper, Tab, Tabs, Typography } from '@mui/material';
import { collection, getDocs, getFirestore, orderBy, query, where } from 'firebase/firestore';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import { MotionViewport } from 'src/components/animate';
import { useAuthContext } from '../../../auth/useAuthContext';
import firebaseApp from '../../../firebase';
// import useResponsive from 'src/hooks/useResponsive';

// ----------------------------------------------------------------------

function CustomTabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

CustomTabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

// Initialize Firestore
const db = getFirestore(firebaseApp);

export default function Tips({ setCurrentPage }) {
  Tips.propTypes = {
    setCurrentPage: PropTypes.func.isRequired,
  };

  const { user } = useAuthContext();

  const [publicTips, setPublicTips] = useState([]);
  const [premiumTips, setPremiumTips] = useState([]);
  const [value, setValue] = useState(0);

  const checkExpireDate = () => {
    const sec = user.expire_date ? user.expire_date.seconds * 1000 : 0;
    const expireDate = new Date(sec);
    const currentDate = new Date();
    return currentDate.getTime() < expireDate.getTime();
  };

  const isSubscribed = user.membership !== '1' && checkExpireDate();

  function createTypographyWithLineBreaks(text) {
    // Split the text by new line characters
    const lines = text.split('\n');

    // Map the lines to Typography components, adding <br /> elements in between
    return lines.map((line, index) => (
      <React.Fragment key={index}>
        {line}
        {index !== lines.length - 1 && <br />} {/* Don't add <br /> after the last line */}
      </React.Fragment>
    ));
  }

  useEffect(() => {
    const fetchPublicTips = async () => {
      try {
        // Reference to the tips collection
        const tipsCollectionRef = collection(db, 'communication');
        // Create a query against the collection
        const q = query(
          tipsCollectionRef,
          where('group', '==', 'Public'), // Apply the filter
          orderBy('date', 'desc') // Sort by date in descending order
        );
        // Get a snapshot of the collection
        const tipsSnapshot = await getDocs(q);
        // Map through documents and set data in state
        const tipsList = tipsSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        setPublicTips(tipsList);
      } catch (error) {
        console.error('Error fetching tips: ', error);
      }
    };

    const fetchPremiumTips = async () => {
      try {
        // Reference to the tips collection
        const tipsCollectionRef = collection(db, 'communication');
        // Create a query against the collection
        const q = query(
          tipsCollectionRef,
          where('group', '==', 'Premium'), // Apply the filter
          orderBy('date', 'desc') // Sort by date in descending order
        );
        // Get a snapshot of the collection
        const tipsSnapshot = await getDocs(q);
        // Map through documents and set data in state
        const tipsList = tipsSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        setPremiumTips(tipsList);
      } catch (error) {
        console.error('Error fetching tips: ', error);
      }
    };

    fetchPublicTips();
    fetchPremiumTips();
  }, []);

  function formatDate(dateString) {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];

    const date = new Date(dateString);
    const dayName = days[date.getDay()];
    const day = date.getDate();
    const month = months[date.getMonth()];
    const year = date.getFullYear();
    const hour = date.getHours();
    const minute = date.getMinutes().toString().padStart(2, '0');

    return `${dayName}, ${day} ${month}, ${year} ${hour}:${minute}`;
  }

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <Container
      component={MotionViewport}
      sx={{
        px: 3,
      }}
    >
      <Box sx={{ mt: 3, mx: 'auto', maxWidth: 720, textAlign: 'center' }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs
            value={value}
            onChange={handleChange}
            sx={{
              span: {
                backgroundColor: '#FFF',
              },
            }}
          >
            <Tab label="Public" {...a11yProps(0)} sx={{ flex: 1, color: '#FFF' }} />
            <Tab label="Premium" {...a11yProps(1)} sx={{ flex: 1, color: '#FFF' }} />
          </Tabs>
        </Box>
        <CustomTabPanel value={value} index={0}>
          {publicTips.map((tip, index) =>
            tip.type === 'Tip' ? (
              <Box
                sx={{
                  backgroundImage: 'linear-gradient(326deg, #076af4, #0d1117 49%, #086af5)',
                  borderRadius: 1,
                  padding: '2px',
                  transition: 'all .2s',
                  position: 'relative',
                  transform: 'none',
                  boxShadow: '0 0 70px rgba(9, 134, 251, .19)',
                  mt: 3,
                  mb: 3,
                  maxWidth: 720,
                }}
              >
                <Paper
                  sx={{
                    boxShadow: '0 2px 7px rgba(20, 20, 43, .06)',
                    backgroundColor: '#0d1117',
                    border: '0px solid rgba(239, 240, 246, .08)',
                    borderRadius: 1,
                  }}
                >
                  <Box
                    sx={{
                      display: 'flex',
                      flexDirection: 'column',
                      background: 'linear-gradient(45deg, #0863e3, transparent)',
                    }}
                  >
                    <Typography variant="h7" sx={{ color: 'primary.contrastText', mt: 1 }}>
                      {formatDate(tip.date.toDate())}
                    </Typography>
                    <Typography variant="h7" sx={{ color: 'primary.contrastText', mb: 1 }}>
                      {tip.title}
                    </Typography>
                  </Box>
                  <Box
                    sx={{
                      display: 'flex',
                      flexDirection: 'column',
                      pb: 2,
                      borderBottomLeftRadius: '8px',
                      borderBottomRightRadius: '8px',
                      px: 4,
                    }}
                  >
                    <Box
                      component="img"
                      alt="Logo"
                      src={tip.imageUrl}
                      sx={{
                        mt: 3,
                        borderRadius: 1,
                      }}
                    />
                    <Box sx={{ display: 'flex', flexDirection: 'row', mt: 2, px: 1 }}>
                      <Typography variant="h7" sx={{ color: '#FFF', fontWeight: '600' }}>
                        Method A
                      </Typography>
                      <Box sx={{ flex: 1 }} />
                      <Typography variant="h7" sx={{ color: '#FFF', fontWeight: '600' }}>
                        {tip.reliability}% (€{' '}
                        {user.bankroll ? (user.bankroll * tip.reliability) / 100 : 0})
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', flexDirection: 'row', mt: 1, px: 1 }}>
                      <Typography variant="h7" sx={{ color: '#FFF', fontWeight: '600' }}>
                        Method B
                      </Typography>
                      <Box sx={{ flex: 1 }} />
                      <Typography variant="h7" sx={{ color: '#FFF', fontWeight: '600' }}>
                        {parseFloat((tip.reliability * 1.5).toFixed(3))}% (€{' '}
                        {user.bankroll ? (user.bankroll * tip.reliability * 1.5) / 100 : 0})
                      </Typography>
                    </Box>
                    {tip.analyses.map((analyse, index2) => (
                      <>
                        <Typography
                          variant="h7"
                          sx={{ color: '#FFF', fontWeight: '600', mt: 2, px: 1, textAlign: 'left' }}
                        >
                          {JSON.parse(analyse).title}
                        </Typography>
                        <Typography
                          variant="h7"
                          sx={{ color: '#FFF', mt: 2, px: 1, textAlign: 'left' }}
                        >
                          {createTypographyWithLineBreaks(JSON.parse(analyse).body)}
                        </Typography>
                      </>
                    ))}
                  </Box>
                </Paper>
              </Box>
            ) : (
              <Box
                sx={{
                  backgroundImage: 'linear-gradient(326deg, #076af4, #0d1117 49%, #086af5)',
                  borderRadius: 1,
                  padding: '2px',
                  transition: 'all .2s',
                  position: 'relative',
                  transform: 'none',
                  boxShadow: '0 0 70px rgba(9, 134, 251, .19)',
                  mt: 3,
                  mb: 3,
                  maxWidth: 720,
                }}
              >
                <Paper
                  sx={{
                    boxShadow: '0 2px 7px rgba(20, 20, 43, .06)',
                    backgroundColor: '#0d1117',
                    border: '0px solid rgba(239, 240, 246, .08)',
                    borderRadius: 1,
                  }}
                >
                  <Box
                    sx={{
                      display: 'flex',
                      flexDirection: 'column',
                      background: 'linear-gradient(45deg, #0863e3, transparent)',
                    }}
                  >
                    <Typography variant="h7" sx={{ color: 'primary.contrastText', mt: 1 }}>
                      {formatDate(tip.date.toDate())}
                    </Typography>
                    <Typography variant="h7" sx={{ color: 'primary.contrastText', mb: 1 }}>
                      {tip.title}
                    </Typography>
                  </Box>
                  <Box
                    sx={{
                      display: 'flex',
                      flexDirection: 'column',
                      pb: 2,
                      borderBottomLeftRadius: '6px',
                      borderBottomRightRadius: '6px',
                      px: 2
                    }}
                  >
                    <Typography
                      variant="h7"
                      sx={{ color: '#FFF', px: 2, mt: 3, mb: 1, textAlign: 'left' }}
                    >
                      {tip.message}
                    </Typography>
                  </Box>
                </Paper>
              </Box>
            )
          )}
        </CustomTabPanel>
        <CustomTabPanel value={value} index={1}>
          {!isSubscribed ? (
            <Paper
              sx={{
                borderRadius: 3,
                textAlign: 'center',
                backgroundColor: 'transparent',
                mt: 15,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                height: '100%',
              }}
            >
              <Box
                sx={{
                  display: 'flex',
                  flexDirection: 'row',
                  width: '100%',
                  mt: 0,
                  columnGap: 1,
                  rowGap: 0,
                  justifyContent: 'center',
                  px: 2,
                }}
              >
                <Box
                  sx={{
                    backgroundImage: 'linear-gradient(326deg, #076af4, #0d1117 49%, #086af5)',
                    minWidth: '540px',
                    borderRadius: '24px',
                    padding: '2px',
                    transition: 'all .2s',
                    position: 'relative',
                    transform: 'none',
                    boxShadow: '0 0 70px rgba(9, 134, 251, .19)',
                  }}
                >
                  <Box
                    sx={{
                      backgroundColor: '#0d1117',
                      width: '100%',
                      height: '100%',
                      border: '1px solid rgba(239, 240, 246, .08)',
                      borderRadius: '24px',
                      transition: 'all .2s',
                      position: 'relative',
                      boxShadow: '0 2px 7px rgba(20, 20, 43, .06)',
                      px: 3,
                      py: 2,
                      justifyContent: 'center',
                      alignItems: 'center',
                      display: 'flex',
                      flexDirection: 'column',
                    }}
                  >
                    <Box
                      sx={{
                        width: '77px',
                        height: '77px',
                        border: '2px solid #0866eb',
                        display: 'flex',
                        alignItems: 'center',
                        borderRadius: 2,
                        justifyContent: 'center',
                      }}
                    >
                      <RemoveModeratorIcon />
                    </Box>
                    <Typography
                      sx={{ color: 'rgb(203, 213, 225)', fontWeight: 400, fontSize: '36px', mt: 2 }}
                    >
                      Purchase Membership
                    </Typography>
                    <Typography
                      sx={{
                        color: 'rgba(203, 213, 225, 0.5)',
                        fontWeight: 400,
                        fontSize: '18px',
                        mt: 1,
                      }}
                    >
                      Please purchase a membership to move forward
                    </Typography>
                    <Box
                      sx={{
                        background: 'linear-gradient(#047efc, #12488f)',
                        position: 'relative',
                        overflow: 'hidden',
                        width: '100%',
                        height: '48px',
                        borderRadius: '8px',
                        mt: 4,
                        mb: 2,
                        ':hover': {
                          opacity: 0.8,
                        },
                      }}
                    >
                      <Button
                        variant="filled"
                        color="inherit"
                        sx={{
                          position: 'relative',
                          zIndex: 2, // Ensure the button text is above the overlay
                          color: '#FFF',
                          width: '100%',
                          height: '48px',
                          fontSize: 16,
                          fontWeight: 400,
                        }}
                        onClick={() => setCurrentPage('Subscriptions')}
                      >
                        Purchase Membership
                      </Button>
                    </Box>
                  </Box>
                </Box>
              </Box>
            </Paper>
          ) : (
            <>
              {premiumTips.map((tip, index) =>
                tip.type === 'Tip' ? (
                  <Box
                    sx={{
                      backgroundImage: 'linear-gradient(326deg, #076af4, #0d1117 49%, #086af5)',
                      borderRadius: 1,
                      padding: '2px',
                      transition: 'all .2s',
                      position: 'relative',
                      transform: 'none',
                      boxShadow: '0 0 70px rgba(9, 134, 251, .19)',
                      mt: 3,
                      mb: 3,
                      maxWidth: 720,
                    }}
                  >
                    <Paper
                      sx={{
                        boxShadow: '0 2px 7px rgba(20, 20, 43, .06)',
                        backgroundColor: '#0d1117',
                        border: '0px solid rgba(239, 240, 246, .08)',
                        borderRadius: 1,
                      }}
                    >
                      <Box
                        sx={{
                          display: 'flex',
                          flexDirection: 'column',
                          background: 'linear-gradient(45deg, #0863e3, transparent)',
                        }}
                      >
                        <Typography variant="h7" sx={{ color: 'primary.contrastText', mt: 1 }}>
                          {formatDate(tip.date.toDate())}
                        </Typography>
                        <Typography variant="h7" sx={{ color: 'primary.contrastText', mb: 1 }}>
                          {tip.title}
                        </Typography>
                      </Box>
                      <Box
                        sx={{
                          display: 'flex',
                          flexDirection: 'column',
                          pb: 2,
                          borderBottomLeftRadius: '8px',
                          borderBottomRightRadius: '8px',
                          px: 4,
                        }}
                      >
                        <Box
                          component="img"
                          alt="Logo"
                          src={tip.imageUrl}
                          sx={{
                            mt: 3,
                            borderRadius: 1,
                          }}
                        />
                        <Box sx={{ display: 'flex', flexDirection: 'row', mt: 2}}>
                          <Typography variant="h7" sx={{ color: '#FFF', fontWeight: '600' }}>
                            Method A
                          </Typography>
                          <Box sx={{ flex: 1 }} />
                          <Typography variant="h7" sx={{ color: '#FFF', fontWeight: '600' }}>
                            {tip.reliability}% (€{' '}
                            {user.bankroll ? (user.bankroll * tip.reliability) / 100 : 0})
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', flexDirection: 'row', mt: 1}}>
                          <Typography variant="h7" sx={{ color: '#FFF', fontWeight: '600' }}>
                            Method B
                          </Typography>
                          <Box sx={{ flex: 1 }} />
                          <Typography variant="h7" sx={{ color: '#FFF', fontWeight: '600' }}>
                            {parseFloat((tip.reliability * 1.5).toFixed(3))}% (€{' '}
                            {user.bankroll ? (user.bankroll * tip.reliability * 1.5) / 100 : 0})
                          </Typography>
                        </Box>
                        {tip.analyses.map((analyse, index2) => (
                          <>
                            <Typography
                              variant="h7"
                              sx={{
                                color: '#FFF',
                                fontWeight: '600',
                                mt: 2,
                                textAlign: 'left',
                              }}
                            >
                              {JSON.parse(analyse).title}
                            </Typography>
                            <Typography
                              variant="h7"
                              sx={{ color: '#FFF', mt: 2, textAlign: 'left' }}
                            >
                              {createTypographyWithLineBreaks(JSON.parse(analyse).body)}
                            </Typography>
                          </>
                        ))}
                      </Box>
                    </Paper>
                  </Box>
                ) : (
                  <Box
                    sx={{
                      backgroundImage: 'linear-gradient(326deg, #076af4, #0d1117 49%, #086af5)',
                      borderRadius: 1,
                      padding: '2px',
                      transition: 'all .2s',
                      position: 'relative',
                      transform: 'none',
                      boxShadow: '0 0 70px rgba(9, 134, 251, .19)',
                      mt: 3,
                      mb: 3,
                      maxWidth: 720,
                    }}
                  >
                    <Paper
                      sx={{
                        boxShadow: '0 2px 7px rgba(20, 20, 43, .06)',
                        backgroundColor: '#0d1117',
                        border: '0px solid rgba(239, 240, 246, .08)',
                        borderRadius: 1,
                      }}
                    >
                      <Box
                        sx={{
                          display: 'flex',
                          flexDirection: 'column',
                          background: 'linear-gradient(45deg, #0863e3, transparent)',
                        }}
                      >
                        <Typography variant="h7" sx={{ color: 'primary.contrastText', mt: 1 }}>
                          {formatDate(tip.date.toDate())}
                        </Typography>
                        <Typography variant="h7" sx={{ color: 'primary.contrastText', mb: 1 }}>
                          {tip.title}
                        </Typography>
                      </Box>

                      <Box
                        sx={{
                          mt: 3,
                          px: 4,
                        }}
                      >
                        <Box
                          component="img"
                          alt="Logo"
                          src={tip.imageUrl}
                          sx={{
                            borderRadius: 1,
                          }}
                        />
                      </Box>
                      <Box
                        sx={{
                          display: 'flex',
                          flexDirection: 'column',
                          pb: 2,
                          borderBottomLeftRadius: '6px',
                          borderBottomRightRadius: '6px',
                          px: 2,
                        }}
                      >
                        <Typography
                          variant="h7"
                          sx={{ color: '#FFF', px: 2, mt: 3, mb: 1, textAlign: 'left' }}
                        >
                          {tip.message
                            .split('.')
                            .filter((sentence) => sentence.trim() !== '')
                            .map((sentence, index2, array) => (
                              <React.Fragment key={index2}>
                                {sentence.trim()}.
                                {index2 < array.length - 1 && (
                                  <>
                                    <br />
                                    <br />{' '}
                                  </>
                                )}{' '}
                                {/* Add <br /> except for the last sentence */}
                              </React.Fragment>
                            ))}
                        </Typography>
                      </Box>
                    </Paper>
                  </Box>
                )
              )}
            </>
          )}
        </CustomTabPanel>
      </Box>
    </Container>
  );
}
