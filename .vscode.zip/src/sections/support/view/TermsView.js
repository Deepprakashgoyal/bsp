import '../../../App.css';
// components
import {
  TermsForm
} from '../components';

// ----------------------------------------------------------------------

export default function TermsView() {
  return (
    <TermsForm/>
  );
}
