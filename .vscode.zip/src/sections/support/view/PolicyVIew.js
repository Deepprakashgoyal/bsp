import '../../../App.css';
// components
import {
  PolicyForm
} from '../components';

// ----------------------------------------------------------------------

export default function PolicyView() {
  return (
    <PolicyForm/>
  );
}
