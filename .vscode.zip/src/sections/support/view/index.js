export { default as TermsView } from './TermsView';
export { default as PolicyView} from './PolicyVIew';