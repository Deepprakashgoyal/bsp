import React, { useState, useEffect } from 'react';
import './css/TennisBetting.css';

const useScreenSize = () => {
  const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 768);

  useEffect(() => {
    const handleResize = () => {
      setIsDesktop(window.innerWidth >= 768);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup the event listener on component unmount
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return isDesktop;
};
const TennisBettingSection = () => {
  const isDesktop = useScreenSize();
  return (
    <section className="section-tennis-betting pb-85">
      <div className="container-1 mx-auto pl-2 pr-2 p-mob-0">
        <div className="tennis-betting-content">
          {isDesktop ? (
            <h2 className="heading-3 text-center pb-37 pb-45">
              <span className="d-block">The best way to earn your first </span>
              <span className="color-variation1 d-block">
                $1000 <span className="color-variation2">with tennis betting</span>
              </span>
            </h2>
          ) : (
            <h2 className="heading-3 text-center pb-37 pb-45">
              <span className="d-block">
                The best way to earn your first <span className="color-variation1">$1000</span> with
              </span>
              <span className="color-variation1 d-block">
                <span className="color-variation2"> tennis betting</span>
              </span>
            </h2>
          )}
          <div className="d-flex flex-wrap-mob text-center column-gap-16">
            <div className="tennis-betting-items">
              <div className="tennis-betting-bg">
                <img className="mb-30" src="https://skyblue-mouse-860210.hostingersite.com/img/Scalable-Strategy.webp" alt="Scalable Strategy" />
                <h3 className="heading-4">Scalable Strategy</h3>
              </div>
            </div>
            <div className="tennis-betting-items">
              <div className="tennis-betting-bg">
                <img
                  className="mb-30 hide-mob"
                  src="https://skyblue-mouse-860210.hostingersite.com/img/Industry-Leading-Tools.webp"
                  alt="Industry-Leading Tools"
                />
                <img
                  className="mb-30 show-mob hide-desk mx-auto"
                  src="https://skyblue-mouse-860210.hostingersite.com/img/Industry-Leading-Tools-m.webp"
                  alt="Industry-Leading Tools Mobile"
                />
                <h3 className="heading-4">Industry-Leading Tools</h3>
              </div>
            </div>
            <div className="tennis-betting-items">
              <div className="tennis-betting-bg">
                <img className="mb-30" src="https://skyblue-mouse-860210.hostingersite.com/img/Work-Anywhere.webp" alt="Work Anywhere" />
                <h3 className="heading-4">Work Anywhere</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TennisBettingSection;
