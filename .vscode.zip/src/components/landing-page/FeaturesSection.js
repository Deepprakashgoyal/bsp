import React, { useState, useEffect } from 'react';
import './css/Features.css';

const useScreenSize = () => {
  const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 768);

  useEffect(() => {
    const handleResize = () => {
      setIsDesktop(window.innerWidth >= 768);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup the event listener on component unmount
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return isDesktop;
};
const FeaturesSection = () => {
  const isDesktop = useScreenSize();
  return (
    <section className="section-features mb-85">
      {isDesktop ? (
        <div className="container pl-5 pr-5">
          <div className="d-flex justify-content-center">
            <ul className="d-flex column-gap-45">
              <li className="d-flex align-items-center column-gap-26">
                <img src="https://skyblue-mouse-860210.hostingersite.com/img/double-check.webp" alt="" />
                <span className="text-variation2">No skills required</span>
              </li>
              <li className="d-flex align-items-center column-gap-26">
                <img src="https://skyblue-mouse-860210.hostingersite.com/img/double-check.webp" alt="" />
                <span className="text-variation2">Bets available on all sportsbooks</span>
              </li>
              <li className="d-flex align-items-center column-gap-26">
                <img src="https://skyblue-mouse-860210.hostingersite.com/img/double-check.webp" alt="" />
                <span className="text-variation2">No tennis background needed</span>
              </li>
            </ul>
          </div>
        </div>
      ) : (
        <div className="container pl-5 pr-5">
          <div className="d-flex justify-content-center">
            <ul className="d-flex column-gap-45">
              <li className="d-flex align-items-center column-gap-26">
                <img src="https://skyblue-mouse-860210.hostingersite.com/img/double-check.webp" alt="" />
                <span className="text-variation2">No skills required</span>
              </li>
              <li className="d-flex align-items-center column-gap-26">
                <img src="https://skyblue-mouse-860210.hostingersite.com/img/double-check.webp" alt="" />
                <span className="text-variation2">Bets on all sportsbooks</span>
              </li>
            </ul>
          </div>
        </div>
      )}
    </section>
  );
};

export default FeaturesSection;
