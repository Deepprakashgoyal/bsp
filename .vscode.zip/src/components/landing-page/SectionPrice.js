/* eslint-disable react/no-unescaped-entities */
/* eslint-disable react/button-has-type */
import React from 'react';
import './css/PriceSection.css';
import { paths } from 'src/routes/paths';
import { useNavigate } from 'react-router';

const SectionPrice = () => {
  const navigate = useNavigate();

  const handleSilverSubscription = async (event) => {
    navigate(paths.register, { replace: true });
  };

  const handleGoldSubscription = async (event) => {
    navigate(paths.register, { replace: true });
  };

  return (
    <section className="section-price" id="SectionPrice">
      <div className="container-2 mx-auto pl-2 pr-2 text-center mb-65">
        <h5 className="heading-h5 mb-35 mb-15">Listen...</h5>
        <h2 className="heading-h2 mb-28">
          I guarantee there's a ton of money to be made, and you'll improve at this game— but only
          if you're able to break your bad habits and are willing to learn a new strategy.
        </h2>
        <p className="text-variation5">
          If you are ready to adopt this, these programs will be a game changer for you
        </p>
      </div>
      <div className="price-row d-flex flex-wrap-mob justify-content-center column-gap-90">
        {/* Silver Program */}
        <div className="price-items">
          <div className="price">
            <div className="price-bg">
              <p className="text-variation6">€850</p>
              <div className="text-variation7">€397</div>
            </div>
          </div>
          <div className="price-content">
            <div className="price-inner-bg">
              <div>
                <img className="price-img" alt="Logo" src="img/silver_large.webp" />
                <div className="price-badge">
                  <div className="price-badge-text">€33/month</div>
                </div>
              </div>
              <h3 className="heading-5">Silver Program</h3>
              <span className="price-description">
                Get yearly access to the Silver Program and effortlessly copy and paste our
                well-analyzed winning bets.
              </span>
              <ul className="price-list-style d-flex flex-column mb-30">
                {[
                  'Copy & Paste Concept',
                  'Telegram Live Channel',
                  'BSP Tennis Betting Model',
                  'Silver Video Content',
                  '<s>Masterclass Channel</s>',
                  '<s>Masterclass Video Content</s>',
                  '<s>Masterclass Zone</s>',
                ].map((item, index) => (
                  <li key={index} className="price-list d-flex">
                    <img alt="check" src="img/checkbox.svg" />
                    <p dangerouslySetInnerHTML={{ __html: item }} />
                  </li>
                ))}
              </ul>
              <div>
                <button onClick={() => handleSilverSubscription()} className="btn-secondary">
                  Start Now <img alt="arrow" src="img/arrow_outward_white.webp" />
                </button>
              </div>
            </div>
          </div>
        </div>
        {/* Gold Program */}
        <div className="price-items">
          <div className="price">
            <div className="price-bg">
              <p className="text-variation6">€2500</p>
              <div className="text-variation7">€997</div>
            </div>
          </div>
          <div className="price-content">
            <div className="price-inner-bg">
              <div>
                <img className="price-img" alt="Logo" src="img/gold_large.webp" />
                <div className="price-badge">
                  <div className="price-badge-text">Most Valuable</div>
                </div>
              </div>
              <h3 className="heading-5">Gold Program</h3>
              <span className="price-description">
                Pay only €997 once to get instant access to all Masterclass features. From the
                second year, it's only €397 annually to maintain access.
              </span>
              <ul className="price-list-style d-flex flex-column mb-30">
                {[
                  'Copy & Paste Concept',
                  'Telegram Live Channel',
                  'BSP Tennis Betting Model',
                  'Silver Video Content',
                  'Masterclass Channel',
                  'Masterclass Video Content',
                  'Masterclass Zone',
                ].map((item, index) => (
                  <li key={index} className="price-list d-flex">
                    <img alt="check" src="img/checkbox.svg" />
                    <p>{item}</p>
                  </li>
                ))}
              </ul>
              <div>
                <button onClick={() => handleGoldSubscription()} className="btn-secondary">
                  Start Now <img alt="arrow" src="img/arrow_outward_white.webp" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
export default SectionPrice;
