import React from 'react';
import './css/Tetimonials.css';

// eslint-disable-next-line react/prop-types
const TestimonialItem = ({ src, alt }) => (
  <div className="testimonials-item">
    <img src={src} alt={alt || 'Testimonial image'} />
  </div>
);
const TestimonialsSection = () => {
  const testimonials = [
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials1.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials4.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials22.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials8.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials19.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials11.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials21.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials2.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials16.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials17.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials9.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials10.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials13.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials7.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials3.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials5.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials18.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials6.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials20.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials12.webp',
    'https://skyblue-mouse-860210.hostingersite.com/img/testimonials14.webp',
  ];

  return (
    <section className="section-tetimonials pb-65">
      <div className="container-3 mx-auto pl-2 pr-2 text-center mb-30">
        <h2 className="heading-h2 mb-28">
          This is what happens when you erase your bad betting habits and adopt a proven strategy.
        </h2>
        <p className="text-variation5">
          No one has ever created as many diverse value and disciplined bettors as us <br />
          that profit from the industry.
        </p>
      </div>
      <div className="container-1 mx-auto">
        <div className="testimonials">
          {testimonials.map((src, index) => (
            <TestimonialItem key={index} src={src} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
