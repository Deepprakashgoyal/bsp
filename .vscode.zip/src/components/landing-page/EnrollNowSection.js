/* eslint-disable react/no-unescaped-entities */
import React from 'react';
import './css/EnrollNow.css';

const EnrollNowSection = () => (
  <section className="section-enroll-now">
    <div className="container-1 mx-auto pl-2 pr-2 text-center mb-78 xs-mb-92">
      <p className="text-variation3 hide-mob">
        This isn't just a 'follow my bets' platform; it's the foundation for building the{' '}
        <mark>right habits and strategy</mark> for your online betting journey. Gain access to the
        tools and secrets of my proven strategy, which has generated six figures over the years,
        starting from scratch. Learn how to approach tennis betting in a{' '}
        <mark>healthy, transformative, and profitable way</mark>. Stay ahead by <br /> identifying
        niche markets where bookmakers often make mistakes, and fast-track your path to generating
        online income with guidance from{' '}
        <mark>
          <span>the top 5%</span>
        </mark>{' '}
        who have achieved success in this industry.
      </p>
      <p className="text-variation3 show-mob hide-desk">
        This isn't just a 'follow my bets' platform; it's the foundation for building{' '}
        <mark>the right habits and strategy</mark> for your online betting journey. Gain access to
        the tools and secrets of my proven strategy, which has generated six figures over the years,
        starting from scratch. Learn how to approach tennis betting in a{' '}
        <mark>healthy, transformative, and profitable way</mark>. Stay ahead by <br /> identifying
        niche markets where bookmakers often make mistakes, and fast-track your path to generating
        online income with guidance from{' '}
        <mark>
          <span>the top 5%</span>
        </mark>{' '}
        who have achieved success in this industry.
      </p>
    </div>
    <div className="container-1 mx-auto pl-2 pr-2 text-center mb-65">
      <h5 className="heading-h5">HERE'S WHAT YOU GET</h5>
      <h2 className="heading-h2 hide-mob">ENROLL NOW FOR IMMEDIATE ACCESS TO</h2>
      <h2 className="heading-h2 hide-desk show-mob">GET IMMEDIATE ACCESS TO</h2>
    </div>
    <div className="container-1 mx-auto pl-2 pr-2">
      {enrollItems.map((item, index) => (
        <div
          key={index}
          className={`enroll-items mt-56 xs-mt-25 ${
            item.hideOnDesktop ? 'hide-desk show-mob' : ''
          }`}
        >
          <div className="enroll-items-bg">
            <img alt={item.alt} src={item.imgSrc} className="enroll-image" />
            <div className="enroll-items-text">
              <h3 className="heading-h3">{item.title}</h3>
              <h4 className="heading-h4">{item.description}</h4>
              <div className="enroll-items-icons pt-15">
                {index >= 3 ? (
                  <>
                    <img alt="check disable" src="https://skyblue-mouse-860210.hostingersite.com/img/check_disable.webp" />
                    <img alt="silver disable" className="mr-10" src="https://skyblue-mouse-860210.hostingersite.com/img/silver_disable.webp" />
                    <img alt="checkmark" src="https://skyblue-mouse-860210.hostingersite.com/img/check.webp" />
                    <img alt="silver" src="https://skyblue-mouse-860210.hostingersite.com/img/gold_enable.webp" />
                  </>
                ) : (
                  <>
                    <img alt="checkmark" src="https://skyblue-mouse-860210.hostingersite.com/img/check.webp" />
                    <img alt="silver" className="mr-10" src="https://skyblue-mouse-860210.hostingersite.com/img/silver_enable.webp" />
                    <img alt="checkmark" src="https://skyblue-mouse-860210.hostingersite.com/img/check.webp" />
                    <img alt="gold" src="https://skyblue-mouse-860210.hostingersite.com/img/gold_enable.webp" />
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  </section>
);

const enrollItems = [
  {
    imgSrc: 'https://skyblue-mouse-860210.hostingersite.com/img/copy_paste_concept.webp',
    alt: 'Copy & Paste Concept',
    title: 'Copy & Paste Concept',
    description:
      'Gain access to our app, where we regularly share multiple bets each week along with comprehensive analyses. Our bankroll calculator tool automatically determines the optimal stake based on your chosen bankroll, enabling you to build a steady, consistent income with just one click per day.',
  },
  {
    imgSrc: 'https://skyblue-mouse-860210.hostingersite.com/img/telegram_live_channel.webp',
    alt: 'Telegram Live Channel',
    title: 'Telegram Live Channel',
    description:
      'Inside the Telegram live channel, you will have access to multiple weekly live calls on high-opportunity days, allowing you to profit from our live betting strategy.',
  },
  {
    imgSrc: 'https://skyblue-mouse-860210.hostingersite.com/img/sports_betting_models.webp',
    alt: 'BSP Tennis Betting Model',
    title: 'BSP Tennis Betting Model',
    description:
      "With this model, you will be able to identify mispriced opportunities and errors made by bookmakers. Our brains often mislead us based on what we see and feel, but this model consolidates all the critical data you need to make accurate predictions and avoid mistakes. It also includes a complete video course on how to use the model effectively. Remember, perception can lie, but data doesn't.",
  },
  {
    imgSrc: 'https://skyblue-mouse-860210.hostingersite.com/img/masterclass_channel.webp',
    alt: 'Masterclass Channel',
    title: 'Masterclass Channel',
    description:
      'In the masterclass channel, we provide our Gold members with weekly previews of tournament court conditions, detailed player insights, and potential value opportunities throughout the week. Our goal through this channel is to give ambitious bettors all the essential information needed to succeed in this industry. Personal high-stakes bets are only shared exclusively here.',
  },
  {
    imgSrc: 'https://skyblue-mouse-860210.hostingersite.com/img/masterclass_video_content.webp',
    alt: 'Masterclass Video Content',
    title: 'Masterclass Video Content',
    description:
      'This video course includes over 20 hours of expertise, where we reveal all the secrets of our strategy, sharing our sources, knowledge, and tools. At the end, we’ve included a proof of concept for our strategy, demonstrating its use in real time as we scaled our account to a €14,000 profit in just two weeks. Every step, including both wins and losses, is documented to help you understand how to start from scratch and effectively scale your betting account using our strategy and tools.',
  },
  {
    imgSrc: 'https://skyblue-mouse-860210.hostingersite.com/img/photopreview.webp',
    alt: 'Masterclass zone',
    title: 'Masterclass zone',
    description:
      "The most important games of the day will be previewed in this section, providing you with detailed, in-depth information that you won't find anywhere else ; insights that can help you avoid mistakes and spot opportunities before others. Remember, the more niche your focus, the better your sources, and the faster you can access key information that bookmakers don't have.",
  },
];

export default EnrollNowSection;
