import { paths } from 'src/routes/paths';
import './css/Header.css';
import WistiaPlayer from './WistiaPlayer';

const Header = () => (
  <header className="pb-65 relative">
    <div className="bg-effect" />
    <div className="container">
      <div className="d-flex justify-content-between align-items-center">
        <div className="logo">
          <a href="https://bspconsult.com/">
            <img src="https://skyblue-mouse-860210.hostingersite.com/img/logo.webp" alt="" />
          </a>
        </div>
        <div className="login">
          <a   href={paths.login} className="btn-white">
            Login
          </a>
        </div>
      </div>
    </div>
    <div className="container pl-5 pr-5 pt-65 d-flex flex-column xs-pl-8 xs-pr-8">
      <span className="hero-subtitle text-center">Pay attention to this 5-minute video</span>
      <h1 className="heading-h1 text-center">
        Step-by-step secret ‘betting system’ just <br />
        to prove anyone can make their first <br />
        $1,000 online with it
      </h1>
      <WistiaPlayer videoId="s9dfisq9e7" wrapper="wistia-player-container-1" />
      <a href="#SectionPrice" className="btn-primary btn-lg">
        → YES! I WANT TO START NOW
      </a>
      <p className="text-variation1 text-center">Secure your spot now before the price goes up.</p>
    </div>
  </header>
);
export default Header;
