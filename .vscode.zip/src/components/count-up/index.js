export { default } from './CountUp';
